# Shopline

Backed by Supabase (free tier) — listings and photos are stored for real and shared
across everyone who visits the site.

## 1. Create your free Supabase project
1. Go to https://supabase.com, sign up free, click "New project."
2. Pick any name/region and a database password (you won't need the password day-to-day).
3. Wait ~1 minute for it to spin up.

## 2. Set up the database and storage
1. In your new project, open the **SQL Editor** (left sidebar).
2. Click "New query," paste in the entire contents of `supabase-setup.sql` from this
   folder, and click **Run**. This creates the `listings` table and a public `photos`
   storage bucket.

## 3. Get your API keys
1. In the project, go to **Settings -> API**.
2. Copy the **Project URL** and the **anon public** key.
3. In this project folder, copy `.env.example` to a new file named `.env`, and paste
   your values in:
   ```
   VITE_SUPABASE_URL=https://xxxxxxx.supabase.co
   VITE_SUPABASE_ANON_KEY=eyJ...
   ```

## 4. Run it locally
```
npm install
npm run dev
```
Opens at http://localhost:5173 — post a listing and check it shows up in your
Supabase project under Table Editor -> listings.

## 5. Deploy for free (Vercel)
1. Push this folder to a GitHub repo (`.env` is gitignored on purpose — never commit it).
2. Go to vercel.com, sign in with GitHub, "Add New Project," pick your repo.
3. Before deploying, open **Environment Variables** in the Vercel project settings and
   add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` with the same values from your `.env`.
4. Click Deploy. You'll get a live URL in about a minute, and it'll be pulling/writing
   real shared data.

## Security note
The admin password gate in the app is a UI convenience, not real security — the
Supabase policies in `supabase-setup.sql` allow anyone with the public anon key
(visible in any deployed site's JS bundle) to read, insert, or delete listings directly
via the API, bypassing the password. That's fine for a prototype or demo. Before this
holds real user data, replace the open delete policy with Supabase Auth so only a
logged-in admin account can delete rows.
