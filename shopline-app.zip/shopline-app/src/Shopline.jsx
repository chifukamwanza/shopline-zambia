import React, { useState, useEffect } from "react";
import { supabase } from "./supabaseClient";

const FONT_IMPORT = `
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=IBM+Plex+Sans:wght@400;500;600&display=swap');
`;

const INK = "#16213A";
const MARIGOLD = "#E8A33D";
const TEAL = "#2E7D6B";
const CLAY = "#B8492E";
const PAPER = "#F7F3EA";

const countries = [
  { name: "Zambia", flag: "🇿🇲", cities: ["Lusaka", "Ndola", "Kitwe", "Chipata", "Livingstone"] },
  { name: "Kenya", flag: "🇰🇪", cities: ["Nairobi", "Mombasa", "Kisumu", "Nakuru", "Eldoret"] },
  { name: "Nigeria", flag: "🇳🇬", cities: ["Lagos", "Abuja", "Ibadan", "Kano", "Port Harcourt"] },
];

const ADMIN_PASSWORD = "shopline2026";

function Wordmark({ size = "text-5xl" }) {
  return (
    <h1
      className={`${size} font-semibold tracking-tight`}
      style={{ fontFamily: "Fraunces, serif", color: INK }}
    >
      Shopline
    </h1>
  );
}

function TopBar({ label, onBack }) {
  return (
    <div className="flex items-center gap-3 mb-6">
      {onBack && (
        <button
          onClick={onBack}
          className="w-9 h-9 flex items-center justify-center rounded-full border-2"
          style={{ borderColor: INK, color: INK }}
          aria-label="Go back"
        >
          ←
        </button>
      )}
      <span
        className="text-sm font-medium"
        style={{ fontFamily: "IBM Plex Sans, sans-serif", color: INK, opacity: 0.6 }}
      >
        {label}
      </span>
    </div>
  );
}

function PrimaryButton({ children, onClick, full, color = MARIGOLD, textColor = INK, disabled }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`px-6 py-3 rounded-lg font-medium transition-transform active:scale-95 ${full ? "w-full" : ""} ${disabled ? "opacity-50" : ""}`}
      style={{
        background: color,
        color: textColor,
        fontFamily: "IBM Plex Sans, sans-serif",
      }}
    >
      {children}
    </button>
  );
}

export default function Shopline() {
  const [page, setPage] = useState("home");
  const [country, setCountry] = useState(null);
  const [listings, setListings] = useState([]);
  const [loadingListings, setLoadingListings] = useState(true);
  const [posting, setPosting] = useState(false);
  const [loadError, setLoadError] = useState("");
  const [form, setForm] = useState({
    title: "",
    price: "",
    desc: "",
    city: "",
    photoFiles: [],
    photoPreviews: [],
    phone: "",
  });
  const [adminAuthed, setAdminAuthed] = useState(false);
  const [adminPassInput, setAdminPassInput] = useState("");
  const [adminError, setAdminError] = useState("");

  // Load all listings from Supabase once on mount.
  useEffect(() => {
    fetchListings();
  }, []);

  async function fetchListings() {
    setLoadingListings(true);
    setLoadError("");
    const { data, error } = await supabase
      .from("listings")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) {
      setLoadError("Couldn't load listings. Check your Supabase setup.");
      console.error(error);
    } else {
      setListings(data || []);
    }
    setLoadingListings(false);
  }

  const goCountry = (c) => {
    setCountry(c);
    setForm((f) => ({ ...f, city: c.cities[0] }));
    setPage("listings");
  };

  const handlePhotos = (e) => {
    const files = Array.from(e.target.files).slice(0, 5);
    const previews = files.map((f) => URL.createObjectURL(f));
    setForm({ ...form, photoFiles: files, photoPreviews: previews });
  };

  async function uploadPhotos(files) {
    const urls = [];
    for (const file of files) {
      const path = `${Date.now()}-${Math.random().toString(36).slice(2)}-${file.name}`;
      const { error } = await supabase.storage.from("photos").upload(path, file);
      if (error) {
        console.error("Upload failed:", error);
        continue;
      }
      const { data } = supabase.storage.from("photos").getPublicUrl(path);
      urls.push(data.publicUrl);
    }
    return urls;
  }

  const handlePost = async () => {
    if (!form.title || !form.price || !form.phone) return;
    setPosting(true);
    const photoUrls = form.photoFiles.length ? await uploadPhotos(form.photoFiles) : [];

    const { data, error } = await supabase
      .from("listings")
      .insert({
        title: form.title,
        price: form.price,
        description: form.desc,
        city: form.city,
        country: country.name,
        phone: form.phone,
        photos: photoUrls,
      })
      .select();

    setPosting(false);

    if (error) {
      console.error(error);
      setLoadError("Couldn't publish that listing. Check your Supabase setup.");
      return;
    }

    setListings([data[0], ...listings]);
    setForm({ title: "", price: "", desc: "", city: country.cities[0], photoFiles: [], photoPreviews: [], phone: "" });
    setPage("listings");
  };

  const whatsappLink = (item) =>
    `https://wa.me/${item.phone.replace(/\D/g, "")}?text=${encodeURIComponent(
      `Hi! I'm interested in your listing "${item.title}" on Shopline.`
    )}`;

  const deleteListing = async (id) => {
    const { error } = await supabase.from("listings").delete().eq("id", id);
    if (error) {
      console.error(error);
      return;
    }
    setListings(listings.filter((l) => l.id !== id));
  };

  const shell = (content, bg = PAPER) => (
    <div style={{ background: bg, minHeight: "100%" }} className="w-full">
      <style>{FONT_IMPORT}</style>
      <div
        className="max-w-md mx-auto px-5 py-8"
        style={{ fontFamily: "IBM Plex Sans, sans-serif", color: INK }}
      >
        {content}
      </div>
    </div>
  );

  // ---------- HOME ----------
  if (page === "home") {
    return shell(
      <div className="flex flex-col items-center text-center pt-20">
        <Wordmark size="text-6xl" />
        <p className="mt-3 text-base" style={{ color: INK, opacity: 0.7 }}>
          Buy and sell, city by city, across Africa.
        </p>
        <div className="mt-10 w-full">
          <PrimaryButton full onClick={() => setPage("country")}>
            Enter Shopline
          </PrimaryButton>
        </div>
        <div className="mt-16 h-px w-16" style={{ background: INK, opacity: 0.2 }} />
        <p className="mt-6 text-xs" style={{ color: INK, opacity: 0.45 }}>
          No sign-up. No middlemen. Just WhatsApp the seller.
        </p>
      </div>,
      INK
    );
  }

  // ---------- COUNTRY PICKER ----------
  if (page === "country") {
    return shell(
      <div>
        <TopBar label="Choose your market" onBack={() => setPage("home")} />
        <Wordmark size="text-3xl" />
        <div className="mt-6 flex flex-col gap-3">
          {countries.map((c) => (
            <button
              key={c.name}
              onClick={() => goCountry(c)}
              className="flex items-center justify-between p-4 rounded-lg border-2 text-left transition-transform active:scale-95"
              style={{ borderColor: INK, background: "white" }}
            >
              <span className="flex items-center gap-3 text-lg font-medium">
                <span className="text-2xl">{c.flag}</span> {c.name}
              </span>
              <span style={{ color: TEAL }}>→</span>
            </button>
          ))}
        </div>
        <button onClick={() => setPage("admin")} className="mt-10 text-sm underline" style={{ color: INK, opacity: 0.5 }}>
          Admin login
        </button>
      </div>
    );
  }

  // ---------- POST FORM ----------
  if (page === "post") {
    return shell(
      <div>
        <TopBar label={`Post in ${country ? country.name : ""}`} onBack={() => setPage(country ? "listings" : "country")} />
        <h2 className="text-2xl font-semibold mb-5" style={{ fontFamily: "Fraunces, serif" }}>
          What are you selling?
        </h2>

        <label className="block text-sm mb-1 opacity-70">Title</label>
        <input
          placeholder="e.g. Samsung Galaxy A14, barely used"
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          className="border-2 p-3 w-full mb-4 rounded-lg outline-none"
          style={{ borderColor: INK }}
        />

        <label className="block text-sm mb-1 opacity-70">Price (local currency)</label>
        <input
          placeholder="e.g. 1200"
          value={form.price}
          onChange={(e) => setForm({ ...form, price: e.target.value })}
          className="border-2 p-3 w-full mb-4 rounded-lg outline-none"
          style={{ borderColor: INK }}
        />

        <label className="block text-sm mb-1 opacity-70">City</label>
        <select
          value={form.city}
          onChange={(e) => setForm({ ...form, city: e.target.value })}
          className="border-2 p-3 w-full mb-4 rounded-lg outline-none bg-white"
          style={{ borderColor: INK }}
        >
          {(country ? country.cities : []).map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>

        <label className="block text-sm mb-1 opacity-70">Description</label>
        <textarea
          placeholder="Condition, reason for selling, any details a buyer should know"
          value={form.desc}
          onChange={(e) => setForm({ ...form, desc: e.target.value })}
          className="border-2 p-3 w-full mb-4 rounded-lg outline-none h-24"
          style={{ borderColor: INK }}
        />

        <label className="block text-sm mb-1 opacity-70">WhatsApp number (with country code)</label>
        <input
          placeholder="e.g. 260971234567"
          value={form.phone}
          onChange={(e) => setForm({ ...form, phone: e.target.value })}
          className="border-2 p-3 w-full mb-4 rounded-lg outline-none"
          style={{ borderColor: INK }}
        />

        <label className="block text-sm mb-1 opacity-70">Photos (up to 5)</label>
        <input type="file" multiple accept="image/*" onChange={handlePhotos} className="mb-2" />
        {form.photoPreviews.length > 0 && (
          <div className="flex gap-2 mb-4 flex-wrap">
            {form.photoPreviews.map((p, i) => (
              <img key={i} src={p} className="w-16 h-16 object-cover rounded-md border-2" style={{ borderColor: INK }} />
            ))}
          </div>
        )}

        {loadError && <p className="text-sm mb-3" style={{ color: CLAY }}>{loadError}</p>}

        <div className="mt-2">
          <PrimaryButton full onClick={handlePost} disabled={posting}>
            {posting ? "Publishing…" : "Publish listing"}
          </PrimaryButton>
        </div>
      </div>
    );
  }

  // ---------- LISTINGS ----------
  if (page === "listings") {
    const items = listings.filter((l) => l.country === country.name);
    return shell(
      <div>
        <TopBar label="Market" onBack={() => setPage("country")} />
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold" style={{ fontFamily: "Fraunces, serif" }}>
            {country.flag} {country.name}
          </h2>
          <button
            onClick={() => setPage("post")}
            className="text-sm font-medium px-4 py-2 rounded-lg"
            style={{ background: TEAL, color: "white" }}
          >
            + Post
          </button>
        </div>

        {loadingListings ? (
          <p className="opacity-60">Loading listings…</p>
        ) : loadError ? (
          <p className="text-sm" style={{ color: CLAY }}>{loadError}</p>
        ) : items.length === 0 ? (
          <div className="border-2 border-dashed rounded-lg p-8 text-center" style={{ borderColor: INK, opacity: 0.6 }}>
            <p className="font-medium">Nothing listed here yet.</p>
            <p className="text-sm mt-1">Be the first to post something in {country.name}.</p>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {items.map((item) => (
              <div key={item.id} className="rounded-lg border-2 overflow-hidden bg-white" style={{ borderColor: INK }}>
                {item.photos && item.photos.length > 0 && (
                  <div className="flex overflow-x-auto">
                    {item.photos.map((p, i) => (
                      <img key={i} src={p} className="w-full h-44 object-cover flex-shrink-0" style={{ minWidth: "100%" }} />
                    ))}
                  </div>
                )}
                <div className="p-4">
                  <div className="flex items-baseline justify-between">
                    <h3 className="font-semibold text-lg" style={{ fontFamily: "Fraunces, serif" }}>
                      {item.title}
                    </h3>
                    <span className="font-semibold" style={{ color: TEAL }}>
                      {item.price}
                    </span>
                  </div>
                  <p className="text-sm opacity-60 mt-1">{item.city}</p>
                  {item.description && <p className="text-sm mt-2">{item.description}</p>}
                  <a
                    href={whatsappLink(item)}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-block mt-4 px-4 py-2 rounded-lg text-sm font-medium"
                    style={{ background: MARIGOLD, color: INK }}
                  >
                    Message on WhatsApp
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  // ---------- ADMIN ----------
  if (page === "admin") {
    if (!adminAuthed) {
      return shell(
        <div>
          <TopBar label="Admin" onBack={() => setPage("country")} />
          <h2 className="text-2xl font-semibold mb-5" style={{ fontFamily: "Fraunces, serif" }}>
            Admin login
          </h2>
          <input
            type="password"
            placeholder="Password"
            value={adminPassInput}
            onChange={(e) => {
              setAdminPassInput(e.target.value);
              setAdminError("");
            }}
            className="border-2 p-3 w-full mb-2 rounded-lg outline-none"
            style={{ borderColor: INK }}
          />
          {adminError && <p className="text-sm mb-3" style={{ color: CLAY }}>{adminError}</p>}
          <PrimaryButton
            full
            onClick={() => {
              if (adminPassInput === ADMIN_PASSWORD) {
                setAdminAuthed(true);
              } else {
                setAdminError("Incorrect password.");
              }
            }}
          >
            Log in
          </PrimaryButton>
        </div>
      );
    }

    return shell(
      <div>
        <TopBar label="Admin" onBack={() => setPage("country")} />
        <h2 className="text-2xl font-semibold mb-5" style={{ fontFamily: "Fraunces, serif" }}>
          All listings ({listings.length})
        </h2>
        {loadingListings ? (
          <p className="opacity-60">Loading…</p>
        ) : listings.length === 0 ? (
          <p className="opacity-60">No listings yet across any market.</p>
        ) : (
          <div className="flex flex-col gap-3">
            {listings.map((item) => (
              <div key={item.id} className="border-2 rounded-lg p-3 bg-white" style={{ borderColor: INK }}>
                <div className="flex items-baseline justify-between">
                  <h3 className="font-semibold">{item.title}</h3>
                  <span style={{ color: TEAL }}>{item.price}</span>
                </div>
                <p className="text-sm opacity-60">
                  {item.city}, {item.country} · {item.phone}
                </p>
                <button onClick={() => deleteListing(item.id)} className="mt-2 text-sm font-medium" style={{ color: CLAY }}>
                  Delete listing
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  return null;
}
