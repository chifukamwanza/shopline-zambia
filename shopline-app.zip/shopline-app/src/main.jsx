import React from "react";
import ReactDOM from "react-dom/client";
import Shopline from "./Shopline.jsx";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Shopline />
  </React.StrictMode>
);
