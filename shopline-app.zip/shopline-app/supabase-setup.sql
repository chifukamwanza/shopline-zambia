-- Run this whole file once in your Supabase project's SQL Editor
-- (Dashboard -> SQL Editor -> New query -> paste -> Run)

-- 1. Table for listings
create table if not exists listings (
  id bigint generated always as identity primary key,
  title text not null,
  price text not null,
  description text,
  city text not null,
  country text not null,
  phone text not null,
  photos text[] default '{}',
  created_at timestamptz default now()
);

-- 2. Row Level Security: this app has no server, so the browser talks to
--    Supabase directly using a public "anon" key. These policies make
--    listings publicly readable, postable, and deletable -- the admin
--    password in the app is a UI convenience, NOT real security. Anyone
--    who inspects the app could call the API directly and bypass it.
--    Fine for a prototype; swap in Supabase Auth before this holds real data.
alter table listings enable row level security;

create policy "Public can read listings"
  on listings for select
  using (true);

create policy "Public can insert listings"
  on listings for insert
  with check (true);

create policy "Public can delete listings"
  on listings for delete
  using (true);

-- 3. Storage bucket for listing photos
insert into storage.buckets (id, name, public)
values ('photos', 'photos', true)
on conflict (id) do nothing;

create policy "Public can upload photos"
  on storage.objects for insert
  with check (bucket_id = 'photos');

create policy "Public can view photos"
  on storage.objects for select
  using (bucket_id = 'photos');
